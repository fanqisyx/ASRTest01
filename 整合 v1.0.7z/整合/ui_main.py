def log_with_time(msg):
    import datetime
    t = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{t}] {msg}")
import datetime
# 主界面逻辑

from PyQt5 import QtWidgets, QtCore, QtGui
from vosk_module import recognize_speech
from tts_module import speak_text
try:
    from tts_module import speak_text_interruptable
except ImportError:
    def speak_text_interruptable(text, stop_event):
        speak_text(text)
from lmstudio_module import query_lmstudio
from config import Config
import json
import os



class SettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.layout = QtWidgets.QFormLayout()
        self.lmstudio_url_edit = QtWidgets.QLineEdit()
        self.lmstudio_model_edit = QtWidgets.QLineEdit()
        self.vosk_model_path_edit = QtWidgets.QLineEdit()
        self.load_config()
        self.layout.addRow("LMStudio地址:", self.lmstudio_url_edit)
        self.layout.addRow("LMStudio模型名:", self.lmstudio_model_edit)
        self.layout.addRow("Vosk模型路径:", self.vosk_model_path_edit)
        btn_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        self.layout.addWidget(btn_box)
        self.setLayout(self.layout)

    def load_config(self):
        config = self.read_config()
        self.lmstudio_url_edit.setText(config.get("lmstudio_url", "http://localhost:1234/v1/chat/completions"))
        self.lmstudio_model_edit.setText(config.get("lmstudio_model", "your-model-name"))
        self.vosk_model_path_edit.setText(config.get("vosk_model_path", "E:/AITools/model/Vosk/vosk-model-cn-0.22"))

    @staticmethod
    def read_config():
        if os.path.exists("config.json"):
            with open("config.json", "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def save_config(self):
        config = {
            "lmstudio_url": self.lmstudio_url_edit.text(),
            "lmstudio_model": self.lmstudio_model_edit.text(),
            "vosk_model_path": self.vosk_model_path_edit.text(),
        }
        with open("config.json", "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)


import threading
import queue
import time


class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.tts_stop_event = threading.Event()  # 控制TTS中断
        self.init_ui()
        self.load_config()
        self.listening = False
        self.voice_queue = queue.Queue()
        self.processing = False
        self.process_lock = threading.Lock()
        self.listen_thread = None
        self.listen_pause = threading.Event()  # 控制收音暂停
        self.listen_stop_event = threading.Event()  # 强制中断收音
        self.listen_discard_event = threading.Event()  # TTS期间丢弃音频

    def append_text(self, msg):
        # 主线程安全append并自动滚动到底部
        def do_append():
            self.text_display.append(msg)
            QtCore.QTimer.singleShot(0, lambda: self.text_display.moveCursor(QtGui.QTextCursor.End))
        if QtCore.QThread.currentThread() == QtWidgets.QApplication.instance().thread():
            do_append()
        else:
            QtCore.QMetaObject.invokeMethod(self.text_display, "append", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, msg))
            QtCore.QTimer.singleShot(0, lambda: self.text_display.moveCursor(QtGui.QTextCursor.End))

    def init_ui(self):
        self.setWindowTitle("语音助手整合Demo")
        main_layout = QtWidgets.QHBoxLayout()

        # 左侧：对话区
        left_layout = QtWidgets.QVBoxLayout()
        self.text_display = QtWidgets.QTextEdit()
        self.text_display.setReadOnly(True)
        left_layout.addWidget(self.text_display)

        btn_layout = QtWidgets.QHBoxLayout()
        self.btn_start = QtWidgets.QPushButton("开始聆听")
        self.btn_start.clicked.connect(self.start_listen)
        self.btn_stop = QtWidgets.QPushButton("停止")
        self.btn_stop.clicked.connect(self.stop_listen)
        self.btn_stop.setEnabled(False)
        self.btn_settings = QtWidgets.QPushButton("设置")
        self.btn_settings.clicked.connect(self.open_settings)
        self.btn_clear = QtWidgets.QPushButton("清空对话")
        self.btn_clear.clicked.connect(self.clear_text_display)
        btn_layout.addWidget(self.btn_start)
        btn_layout.addWidget(self.btn_stop)
        btn_layout.addWidget(self.btn_settings)
        btn_layout.addWidget(self.btn_clear)
        left_layout.addLayout(btn_layout)

        # 右侧：状态和任务队列
        right_layout = QtWidgets.QVBoxLayout()
        # 收音状态指示灯
        status_layout = QtWidgets.QHBoxLayout()
        self.label_status = QtWidgets.QLabel("收音状态：")
        self.status_light = QtWidgets.QLabel()
        self.set_status_light(False)
        status_layout.addWidget(self.label_status)
        status_layout.addWidget(self.status_light)
        status_layout.addStretch()
        right_layout.addLayout(status_layout)

        # 任务队列列表
        self.label_queue = QtWidgets.QLabel("任务队列：")
        self.list_queue = QtWidgets.QListWidget()
        right_layout.addWidget(self.label_queue)
        right_layout.addWidget(self.list_queue)
        right_layout.addStretch()

        main_layout.addLayout(left_layout, 3)
        main_layout.addLayout(right_layout, 1)
        self.setLayout(main_layout)

    def set_status_light(self, listening):
        # listening: True=绿色，False=灰色
        color = "#00FF00" if listening else "#AAAAAA"
        # 用QPixmap画圆形指示灯
        pixmap = QtWidgets.QLabel().grab().scaled(16, 16)
        from PyQt5.QtGui import QPixmap, QPainter, QColor
        pix = QPixmap(16, 16)
        pix.fill(QtCore.Qt.transparent)
        painter = QPainter(pix)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor(color))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawEllipse(0, 0, 16, 16)
        painter.end()
        self.status_light.setPixmap(pix)

    def clear_text_display(self):
        self.text_display.clear()

    def load_config(self):
        config = SettingsDialog.read_config()
        self.lmstudio_url = config.get("lmstudio_url", "http://localhost:1234/v1/chat/completions")
        self.lmstudio_model = config.get("lmstudio_model", "your-model-name")
        self.vosk_model_path = config.get("vosk_model_path", "E:/AITools/model/Vosk/vosk-model-cn-0.22")

    def open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            dlg.save_config()
            self.load_config()
            msg = f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [系统] 设置已保存"
            self.text_display.append(msg)
            log_with_time("[系统] 设置已保存")

    def start_listen(self):
        if self.listening:
            return
        # 等待上一个处理线程完全退出
        with self.process_lock:
            self.processing = False
        self.tts_stop_event.clear()  # 重置TTS中断标志
        self.listening = True
        self.set_status_light(False)  # 加载模型等准备阶段为灰色
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        msg = f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [系统] 开始持续聆听语音指令..."
        self.append_text(msg)
        log_with_time("[系统] 开始持续聆听语音指令...")
        self.listen_thread = threading.Thread(target=self.listen_loop, daemon=True)
        self.listen_thread.start()
        self.process_next()

    def stop_listen(self):
        self.listening = False
        self.processing = False  # 停止处理线程
        self.tts_stop_event.set()  # 通知TTS中断
        self.set_status_light(False)
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        msg = f"[{datetime.datetime.now().strftime('%H:%M:%S')}] [系统] 已停止聆听。"
        self.append_text(msg)
        log_with_time("[系统] 已停止聆听。")

    def listen_loop(self):
        import vosk_module
        # 加载模型等准备阶段，指示灯为灰色
        self.set_status_light(False)
        while self.listening:
            if self.listen_pause.is_set():
                time.sleep(0.1)
                continue
            self.listen_stop_event.clear()
            # 真正进入收音前，指示灯变为绿色
            self.set_status_light(True)
            text = vosk_module.recognize_speech(self.vosk_model_path, stop_event=self.listen_stop_event, discard_event=self.listen_discard_event)
            # 只有在非丢弃期间才入队
            if text and not self.listen_discard_event.is_set():
                self.voice_queue.put(text)
                self.update_queue_list()
            time.sleep(0.1)

    def process_next(self):
        # 用锁防止多线程并发
        if self.processing:
            return
        def nowstr():
            return datetime.datetime.now().strftime("%H:%M:%S")
        def _process():
            with self.process_lock:
                self.processing = True
                try:
                    while self.listening or not self.voice_queue.empty():
                        if not self.voice_queue.empty():
                            text = self.voice_queue.get()
                            self.update_queue_list()
                            msg_user = f"[{nowstr()}] [你] {text}"
                            self.append_text(msg_user)
                            log_with_time(f"[你] {text}")
                            # 显示加载模型等内容
                            msg_sys = f"[{nowstr()}] [系统] 正在加载模型与生成回复..."
                            self.append_text(msg_sys)
                            log_with_time("[系统] 正在加载模型与生成回复...")
                            # 暂停收音
                            self.listen_pause.set()
                            self.set_status_light(False)  # 生成回复期间不收音
                            thinking, answer = query_lmstudio(text, self.lmstudio_url, self.lmstudio_model)
                            if thinking:
                                msg_think = f"[{nowstr()}] [思考] {thinking}"
                                self.append_text(msg_think)
                                log_with_time(f"[思考] {thinking}")
                            msg_ai = f"[{nowstr()}] [AI] {answer}"
                            self.append_text(msg_ai)
                            log_with_time(f"[AI] {answer}")
                            # TTS朗读期间丢弃收音数据，指示灯灰色
                            self.listen_discard_event.set()
                            self.set_status_light(False)
                            speak_text_interruptable(answer, self.tts_stop_event)
                            self.listen_discard_event.clear()
                            # 朗读结束后恢复收音和指示灯
                            self.listen_pause.clear()
                            if self.listening:
                                self.set_status_light(True)
                        else:
                            time.sleep(0.1)
                finally:
                    self.processing = False
        threading.Thread(target=_process, daemon=True).start()

    def update_queue_list(self):
        # 展示未执行的指令队列
        self.list_queue.clear()
        items = list(self.voice_queue.queue)
        for i, item in enumerate(items):
            self.list_queue.addItem(f"{i+1}. {item}")

def run_app():
    import sys
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())
