# 配置管理

class Config:
    LMSTUDIO_API_URL = "http://localhost:1234/api"  # 示例
    TTS_PARAMS = {}
    VOSK_PARAMS = {}
