# 主程序入口
from ui_main import run_app

if __name__ == "__main__":
    run_app()
